
// cs204_guiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cs204_gui.h"
#include "cs204_guiDlg.h"
#include "afxdialogex.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// Ccs204_guiDlg dialog



Ccs204_guiDlg::Ccs204_guiDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(Ccs204_guiDlg::IDD, pParent)
	, displayFormatRadio(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Ccs204_guiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, input1);
	DDX_Control(pDX, IDC_EDIT2, input2);
	DDX_Control(pDX, myStaticText, my_Static_Text);
	DDX_Radio(pDX, IDC_RADIO4, displayFormatRadio);
}

BEGIN_MESSAGE_MAP(Ccs204_guiDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &Ccs204_guiDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &Ccs204_guiDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &Ccs204_guiDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &Ccs204_guiDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &Ccs204_guiDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &Ccs204_guiDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &Ccs204_guiDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &Ccs204_guiDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &Ccs204_guiDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON10, &Ccs204_guiDlg::OnBnClickedButton10)
	ON_BN_CLICKED(IDC_BUTTON11, &Ccs204_guiDlg::OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON12, &Ccs204_guiDlg::OnBnClickedButton12)
	ON_BN_CLICKED(IDC_BUTTON13, &Ccs204_guiDlg::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON14, &Ccs204_guiDlg::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON15, &Ccs204_guiDlg::OnBnClickedButton15)
	ON_BN_CLICKED(IDC_RADIO4, &Ccs204_guiDlg::OnBnClickedRadio4)
	ON_BN_CLICKED(IDC_RADIO5, &Ccs204_guiDlg::OnBnClickedRadio5)
	ON_BN_CLICKED(IDC_RADIO6, &Ccs204_guiDlg::OnBnClickedRadio6)
END_MESSAGE_MAP()


// Ccs204_guiDlg message handlers

BOOL Ccs204_guiDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void Ccs204_guiDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Ccs204_guiDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Ccs204_guiDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

bool isOperatorPressed = false;
CString operatorPressed;

void Ccs204_guiDlg::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 1);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 1);

		content += num;

		input2.SetWindowTextW(content);
	}
}


void Ccs204_guiDlg::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 2);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 2);

		content += num;

		input2.SetWindowTextW(content);
	
	}
}


void Ccs204_guiDlg::OnBnClickedButton3()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 3);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 3);

		content += num;

		input2.SetWindowTextW(content);
	
	}
}


void Ccs204_guiDlg::OnBnClickedButton4()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 4);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 4);

		content += num;

		input2.SetWindowTextW(content);
	
	}
}


void Ccs204_guiDlg::OnBnClickedButton5()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 5);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 5);

		content += num;

		input2.SetWindowTextW(content);
	
	}
}


void Ccs204_guiDlg::OnBnClickedButton6()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 6);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 6);

		content += num;

		input2.SetWindowTextW(content);
	
	}
}


void Ccs204_guiDlg::OnBnClickedButton7()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 7);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 7);

		content += num;

		input2.SetWindowTextW(content);
	
	}
}


void Ccs204_guiDlg::OnBnClickedButton8()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 8);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 8);

		content += num;

		input2.SetWindowTextW(content);
	
	}
}


void Ccs204_guiDlg::OnBnClickedButton9()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 9);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 9);

		content += num;

		input2.SetWindowTextW(content);
	
	}
}


void Ccs204_guiDlg::OnBnClickedButton10()
{
	// TODO: Add your control notification handler code here
	if(!isOperatorPressed)
	{
		CString num, content;
	
		input1.GetWindowTextW(content);
		num.Format(_T("%d"), 0);

		content += num;

		input1.SetWindowTextW(content);
	}
	else
	{
		CString num, content;
	
		input2.GetWindowTextW(content);
		num.Format(_T("%d"), 0);

		content += num;

		input2.SetWindowTextW(content);
	}
}


void Ccs204_guiDlg::OnBnClickedButton11()
{
	// TODO: Add your control notification handler code here
	isOperatorPressed = true;
	operatorPressed.Format(_T("+"));
}


void Ccs204_guiDlg::OnBnClickedButton12()
{
	// TODO: Add your control notification handler code here
	isOperatorPressed = true;
	operatorPressed.Format(_T("-"));
}


void Ccs204_guiDlg::OnBnClickedButton13()
{
	// TODO: Add your control notification handler code here
	isOperatorPressed = true;
	operatorPressed.Format(_T("*"));
}


void Ccs204_guiDlg::OnBnClickedButton14()
{
	// TODO: Add your control notification handler code here
	isOperatorPressed = true;
	operatorPressed.Format(_T("/"));
}


void Ccs204_guiDlg::OnBnClickedButton15()
{
	// TODO: Add your control notification handler code here
		CString num1, num2, result;
	double num1d, num2d;

	UpdateData(true);
	input1.GetWindowTextW(num1);
	input2.GetWindowTextW(num2);

	num1d = _ttof(num1);
	num2d = _ttof(num2);

	if(displayFormatRadio == 0)
	{
		if(operatorPressed == _T("+"))
			result.Format(_T("%.2f"), num1d + num2d);
		else if(operatorPressed == _T("-"))
			result.Format(_T("%.2f"), num1d - num2d);
		else if(operatorPressed == _T("*"))
			result.Format(_T("%.2f"), num1d * num2d);
		else
			result.Format(_T("%.2f"), num1d / num2d);
	}
	else if(displayFormatRadio == 1)
	{
		if(operatorPressed == _T("+"))
			result.Format(_T("%.3f"), num1d + num2d);
		else if(operatorPressed == _T("-"))
			result.Format(_T("%.3f"), num1d - num2d);
		else if(operatorPressed == _T("*"))
			result.Format(_T("%.3f"), num1d * num2d);
		else
			result.Format(_T("%.3f"), num1d / num2d);
	}
	else if(displayFormatRadio == 2)
	{
		if(operatorPressed == _T("+"))
			result.Format(_T("%.5f"), num1d + num2d);
		else if(operatorPressed == _T("-"))
			result.Format(_T("%.5f"), num1d - num2d);
		else if(operatorPressed == _T("*"))
			result.Format(_T("%.5f"), num1d * num2d);
		else
			result.Format(_T("%.5f"), num1d / num2d);
	}
	else
	{
		//no selection, do nothing
	}

	my_Static_Text.SetWindowTextW(result);

	input1.SetWindowTextW(_T(""));
	input2.SetWindowTextW(_T(""));

	isOperatorPressed = false;
}




void Ccs204_guiDlg::OnBnClickedRadio4()
{
		// TODO: Add your control notification handler code here
	CString result;
	double result_d;
	my_Static_Text.GetWindowTextW(result);
	result_d = _ttof(result);

	result.Format(_T("%.2f"), result_d);

	my_Static_Text.SetWindowTextW(result);
}


void Ccs204_guiDlg::OnBnClickedRadio5()
{
	// TODO: Add your control notification handler code here
	CString result;
	double result_d;
	my_Static_Text.GetWindowTextW(result);
	result_d = _ttof(result);

	result.Format(_T("%.3f"), result_d);

	my_Static_Text.SetWindowTextW(result);
}

void Ccs204_guiDlg::OnBnClickedRadio6()
{
	// TODO: Add your control notification handler code here
	CString result;
	double result_d;
	my_Static_Text.GetWindowTextW(result);
	result_d = _ttof(result);

	result.Format(_T("%.5f"), result_d);

	my_Static_Text.SetWindowTextW(result);
}
