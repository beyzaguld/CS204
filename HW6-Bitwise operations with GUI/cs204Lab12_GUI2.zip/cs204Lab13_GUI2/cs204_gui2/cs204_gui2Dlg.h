
// cs204_gui2Dlg.h : header file
//

#pragma once
#include "afxwin.h"


// Ccs204_gui2Dlg dialog
class Ccs204_gui2Dlg : public CDialogEx
{
// Construction
public:
	Ccs204_gui2Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_CS204_GUI2_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	CEdit input1;
	CEdit input2;
	CListBox list;
	CButton check1;
	CButton check2;
	CButton check3;
	CButton check4;
	CComboBox combo1;
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnEnChangeEdit2();
	afx_msg void OnBnClickedCheck1();
	CButton other;
	CComboBox advanced;
	afx_msg void OnBnClickedOther();
};
