
// HW6Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "HW6.h"
#include "HW6Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CHW6Dlg dialog



CHW6Dlg::CHW6Dlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CHW6Dlg::IDD, pParent)
	, operator_input(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHW6Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, operand_input1);
	DDX_Control(pDX, IDC_EDIT2, operand_input2);
	DDX_Control(pDX, IDC_CHECK1, shift_check);
	DDX_Control(pDX, IDC_COMBO1, shift_direction);
	DDX_Control(pDX, IDC_EDIT3, bits_to_shift_input);
	DDX_Control(pDX, IDC_BUTTON1, myButton);
	DDX_Control(pDX, IDC_LIST1, myResult);
	DDX_Radio(pDX, IDC_RADIO4, operator_input);
}

BEGIN_MESSAGE_MAP(CHW6Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CHW6Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_CHECK1, &CHW6Dlg::OnBnClickedCheck1)
//	ON_BN_CLICKED(IDC_RADIO4, &CHW6Dlg::OnBnClickedRadio4)
END_MESSAGE_MAP()


// CHW6Dlg message handlers

BOOL CHW6Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	shift_direction.SetCurSel(0);
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHW6Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHW6Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHW6Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


int maxSize = 0;
void CHW6Dlg::OnBnClickedButton1()
{
	UpdateData(TRUE);
	CString operand1, operand2, shift_direction_Cstr, bits_to_shift, result, total_Cstr, myOperator;
	unsigned int opr1, opr2, bits, total;
	bool checker = TRUE;
	CDC *pDC = GetDC();
	CSize cz;
	
	//get and store the operand inputs that user entered
	operand_input1.GetWindowTextW(operand1);
	operand_input2.GetWindowTextW(operand2);

	//convert CString type operand inputs to unsigned integer type
	opr1 = _tcstoul(operand1,nullptr,10);
	opr2 = _tcstoul(operand2,nullptr,10);
	
	//if user entered both operand 1 and operand 2
	if (operand1.GetLength() > 0 && operand2.GetLength() > 0) {

		//if shift is checked
		if (shift_check.GetCheck()) {
			//get shift direction
			int selectIdx = shift_direction.GetCurSel();
			shift_direction.GetLBText(selectIdx, shift_direction_Cstr);

			//get and store the bit number input that user entered
			bits_to_shift_input.GetWindowTextW(bits_to_shift);

			//if number of bits are specified
			if (bits_to_shift.GetLength() > 0) {

				//convert bits_to_shift CString value to unsigned integer
				bits = _tcstoul(bits_to_shift,nullptr,10);
				
				if (shift_direction_Cstr == _T("Right")) {
					//shift to right bits many times
					opr1 = opr1 >> bits;
					opr2 = opr2 >> bits;
					//update operand1 and operand2 values using conversion of opr1 and opr2 to CString
					operand1.Format(_T("%u"), opr1);
					operand2.Format(_T("%u"), opr2);
				}
				else if (shift_direction_Cstr == _T("Left")) {
					//shift to left bits many times
					opr1 = opr1 << bits;
					opr2 = opr2 << bits;
					//update operand1 and operand2 values using conversion of opr1 and opr2 to CString
					operand1.Format(_T("%u"), opr1);
					operand2.Format(_T("%u"), opr2);
				}
			}
			//if number of bits are not specified
			else {
				result = _T("Specify how many bits you want to shift");
				checker = FALSE;
			}
		}
		//if number of bits are entered
		if (checker) {
			operand1.Format(_T("%u"), opr1);
			operand2.Format(_T("%u"), opr2);

			result = operand1;
			//if operator is AND
			if (operator_input == 0) {
				total = opr1 & opr2;
				result += _T(" AND ");
			}

			//if operator is OR
			else if (operator_input == 1) {
				total = opr1 | opr2;
				result += _T(" OR ");
			}

			//if operator is XOR
			else if (operator_input == 2) {
				total = opr1 ^ opr2;
				result += _T(" XOR ");
			}

			result += operand2;
			result += _T(" = ");
			total_Cstr.Format(_T("%u"), total);
			result += total_Cstr;
		}
	}
	//if user did not enter at least one of the operands
	else {
		result = _T("At least one operand was not entered.");
	}

	//add result to myResult to display it on the screen
	myResult.AddString(result);
	cz = pDC->GetTextExtent(result);
	if(cz.cx > maxSize)
		maxSize = cz.cx;
	myResult.SetHorizontalExtent(maxSize);

}


void CHW6Dlg::OnBnClickedCheck1()
{
	//if shift is checked, enable shift direction option
	if (shift_check.GetCheck()) 
		shift_direction.EnableWindow(TRUE);
	else 
		shift_direction.EnableWindow(FALSE);

	//if shift is checked, enable user to write number of bits to shift
	if (shift_check.GetCheck()) 
		bits_to_shift_input.EnableWindow(TRUE);
	else 
		bits_to_shift_input.EnableWindow(FALSE);
}