
// HW6Dlg.h : header file
//

#pragma once
#include "afxwin.h"


// CHW6Dlg dialog
class CHW6Dlg : public CDialogEx
{
// Construction
public:
	CHW6Dlg(CWnd* pParent = NULL);	// standard constructor


// Dialog Data
	enum { IDD = IDD_HW6_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CEdit operand_input1;
	CEdit operand_input2;
	CButton operator_and;
	CButton shift_check;
	CComboBox shift_direction;
	CEdit bits_to_shift_input;
	CButton myButton;
	CListBox myResult;
	afx_msg void OnBnClickedButton1();
	int operator_input;
	afx_msg void OnBnClickedCheck1();
//	afx_msg void OnBnClickedRadio4();
};
